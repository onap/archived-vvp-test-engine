import responses
from onap_client.sdc.vsp import VSP

@responses.activate
def test_vsp_create():
    VSP_MODEL_ID = "test"
    VSP_MODEL_VERSION_ID = "test"

    return_data = {
        "itemId": VSP_MODEL_ID,
        "version": {"id": VSP_MODEL_VERSION_ID},
    }
    responses.add(
        responses.POST,
        "https://sdc.api.be.simpledemo.onap.org:31360/onboarding-api/v1.0/vendor-software-products",
        json=return_data,
    )
